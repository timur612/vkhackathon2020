self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5f455a8e0ebe5c5ae523b7b29ef8a3c3",
    "url": "/index.html"
  },
  {
    "revision": "3b92c5c7d7abfdadb63b",
    "url": "/static/css/2.6326594c.chunk.css"
  },
  {
    "revision": "3b92c5c7d7abfdadb63b",
    "url": "/static/js/2.483aff1e.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.483aff1e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2d80c8fa6c395fd509e0",
    "url": "/static/js/main.dadd1a72.chunk.js"
  },
  {
    "revision": "50bfbce336dace4beebb",
    "url": "/static/js/runtime-main.8757f449.js"
  },
  {
    "revision": "0ef8af463dd50be1df2cec3076172357",
    "url": "/static/media/Ячейки.0ef8af46.svg"
  }
]);