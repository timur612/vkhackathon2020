self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9c528a4f983decf59817a4d7f39f3ef9",
    "url": "/index.html"
  },
  {
    "revision": "e76df45672d91e0d3ac9",
    "url": "/static/css/2.6326594c.chunk.css"
  },
  {
    "revision": "e76df45672d91e0d3ac9",
    "url": "/static/js/2.df3d005d.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.df3d005d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c771727539116da3c94b",
    "url": "/static/js/main.6c31fd50.chunk.js"
  },
  {
    "revision": "50bfbce336dace4beebb",
    "url": "/static/js/runtime-main.8757f449.js"
  },
  {
    "revision": "b364b369837611730ccdd112b62f32a1",
    "url": "/static/media/Icon_calc.b364b369.svg"
  },
  {
    "revision": "f8b43a8ed45cf230026603752fb1e1a2",
    "url": "/static/media/Icon_calc_active.f8b43a8e.svg"
  },
  {
    "revision": "183271fa810ce75178824f5f75162d65",
    "url": "/static/media/Icon_home.183271fa.svg"
  },
  {
    "revision": "4b390716ad8b465b1a39acedfeb44d7b",
    "url": "/static/media/Icon_home_active.4b390716.svg"
  },
  {
    "revision": "b5590e222383eecdd8f051c14d05f038",
    "url": "/static/media/Icon_profile.b5590e22.svg"
  },
  {
    "revision": "267ec10c124b9ab3a2e99562c50b48b0",
    "url": "/static/media/Icon_profile_active.267ec10c.svg"
  },
  {
    "revision": "c6fd56e483627be2cdd3e09e6959a511",
    "url": "/static/media/notification.c6fd56e4.svg"
  },
  {
    "revision": "be11f98138f767f24464a0226588ada5",
    "url": "/static/media/result.be11f981.svg"
  },
  {
    "revision": "0bd1b5c14e50fe7edcde114432648507",
    "url": "/static/media/result1.0bd1b5c1.svg"
  },
  {
    "revision": "f3620433f62d1bd03598e61798e00731",
    "url": "/static/media/tax1.f3620433.svg"
  },
  {
    "revision": "cf149693d7a5296c7bfb2c60c78cb6db",
    "url": "/static/media/tax2.cf149693.svg"
  },
  {
    "revision": "86491f13e82d8df7fd8996cdb6aa55c3",
    "url": "/static/media/tax3.86491f13.svg"
  },
  {
    "revision": "b46fb3dcdb6bd664cb3a58b7e749c3a5",
    "url": "/static/media/tax4.b46fb3dc.svg"
  },
  {
    "revision": "0ef8af463dd50be1df2cec3076172357",
    "url": "/static/media/Ячейки.0ef8af46.svg"
  }
]);