self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "782560a7d6a7877277c3ded195ded5da",
    "url": "/vkhackathon2020/index.html"
  },
  {
    "revision": "a3b305c727bdd5392eb5",
    "url": "/vkhackathon2020/static/css/2.6326594c.chunk.css"
  },
  {
    "revision": "a3b305c727bdd5392eb5",
    "url": "/vkhackathon2020/static/js/2.6620004f.chunk.js"
  },
  {
    "revision": "570d362d673dab785e62d2b8563e1118",
    "url": "/vkhackathon2020/static/js/2.6620004f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e9a74e0fe3245911521e",
    "url": "/vkhackathon2020/static/js/main.d569e829.chunk.js"
  },
  {
    "revision": "c59139ae3d97fd8f23f9",
    "url": "/vkhackathon2020/static/js/runtime-main.582b93d9.js"
  }
]);